class PrizeCategory {

    var prizeName: String
    var prizeTicketCost: Int
    var prizeTally: Int

    constructor(name: String, cost: Int, tally: Int){
        prizeName = name
        prizeTicketCost = cost
        prizeTally = tally
    }

}